# 📘 Lector Japonés - Comparativo y Voz

Aplicación web para leer japonés con furigana, voz y traducción comparativa.

## 🚀 Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube `index.html` y `README.md`.
3. Activa GitHub Pages desde Settings > Pages.
4. Visita https://<tu-usuario>.github.io/<nombre-del-repo>/
